$('document').ready(function () {
  var page = location.pathname.split('/').pop();
  $('nav.navbar li a[href="http://localhost/Internshala/blood_bank/' + page + '"]').addClass('active');
  /** -------------------------------------Registration js receiver------------------------ */
  $('#rgstrBtnRcvr').click(function () {
    receiverData = $("#rgstrRcvr").serialize();
    $.ajax({
      type: "POST",
      url: 'register-controller.php  ',
      data: receiverData,
      dataType: "json",
      success: function (response) {
        console.log(response);
        if (response.status === 1) {
          
          $(".messageBox").html('<div class="alert alert-success"><strong>Success!</strong> ' + response.content + '. <button class="btn btn-primary" data-toggle="modal" data-target="#showLogin">Login</button></div>');
        } else {
          $(".messageBox").html('<div class="alert alert-warning"><strong>Warning!</strong> ' + response.content + '. </div>');
          $("div.alert-warning").css('display', 'block');
        }
      },
    });
  });

  /** --------------------------------Registration js hospital--------------------------------- */
  $('#rgstrBtnHosp').click(function () {
    hospitalData = $("#rgstrHosp").serialize();
    $.ajax({
      type: "POST",
      url: 'register-controller.php',
      data: hospitalData,
      dataType: "json",
      success: function (response) {
        console.log(response);
        if (response.status == 1) {
          $(".messageBox").html('<div class="alert alert-success"><strong>Success!</strong> ' + response.content + '. <button class="btn btn-primary" data-toggle="modal" data-target="#showLogin">Login</button></div>');
        } else {
          $(".messageBox").html('<div class="alert alert-warning"><strong>Warning!</strong> ' + response.content + '. </div>');
        }
      },
    });
  });

  /** ---------------------------------------login form on all pages js----------------- */
  $('#checkHospital').on('change', function () {
    var hiddenField = $('#userType'),
      val = hiddenField.val();
    hiddenField.val(val === "receiver" ? "hospital" : "receiver");
  });
  $("#loginBtn").click(function (e) {
    loginData = $("#loginForm").serialize();

    $.ajax({
      url: 'login-controller.php',
      type: 'POST',
      data: loginData,
      dataType: 'json',
      success: function (response) {
        console.log(response);
        if (response.status == 1) {
          $("#messageBox").hide();
          if (response.userType === 'receiver') {
            location.href = 'http://localhost/Internshala/blood_bank/available-blood-to-all.php';
          } else if (response.userType === 'hospital') {
            location.href = 'http://localhost/Internshala/blood_bank/hospital-home.php';
          }
          else {
            $("#messageBox").html("<h4>" + response.content + "</h4>");
          }
        } else {
          $("#messageBox").show();
          $("#messageBox").html("<h4>" + response.content + "</h4>");
        }
      }
    });
    e.preventDefault();
  });

  /** --------------------------------js for datatables-------------------------------------------
   */
  $(document).ready(function () {
    $('#availBloodHosp').DataTable();
    $('#allRequestsHosp').DataTable();
    $('#availBloodToAll').DataTable();
  });

  /**------------------------------ request completed----------------------------------------- */
  $(".reqCompleted").click(function () {
    $.ajax({
      url: 'request-complete-controller.php',
      type: 'POST',
      dataType: 'json',

    });
  });

  /**-------------------------------js for add new blood on hospital add blood---------------- */
  $("#addNewBlood").click(function (e) {
    e.preventDefault();
    newBlood = $("#addBloodForm").serialize();
    $.ajax({
      url: 'add-blood-controller.php',
      type: 'POST',
      data: newBlood,
      dataType: 'json',
      success: function (response) {
        console.log(response);
        if (response.status == 1) {
          $("#messageBox").html("<h4 class='alert alert-success'>" + response.content + "</h4>");
        } else {
          $("#messageBox").html("<h4 class='alert alert-warning'>" + response.content + "</h4>");
          $(".alert-warning").show();
        }
      }
    });
  });

  /**------------------------Destroying session on logout---------------------------------- */
  $("#logout").click(function () {
    choice = confirm('Are you sure');
    console.log(choice);
    if (choice) {
      $.ajax({
        url: 'logout-controller.php',
        type: 'GET',
        dataType: 'json',
        success: function (response) {
          if (response.status === 1) {
            location.reload();
          }
        }
      });
    }
  });

  /**---------------------------------Request Sample button-------------------------- */
  $(".reqSample").click(function () {
    req = {
      reqName: $("#reqName").val(),
      reqPhone: $("#reqPhone").val(),
      reqBgroup: $(this).closest("tr").find(".bgroup").text(),
      hospName: $(this).closest("tr").find(".hospName").text(),
    };

    $.ajax({
      url: 'request-sample-controller.php',
      type: 'POST',
      data: req,
      dataType: 'json',
      success: function (response) {
        console.log(response);
        if (response.status == 1) {
          alert('(' + req.reqBgroup + ') blood group requested successfully from ' + req.hospName);
        } else {
          alert("Request Unsuccessfull");
        }
      }
    });
  });
});


